readme.txt

Group members:
Jia Zhang, zhan7164@umn.edu
Ce Yao, yao00136@umn.edu

Test cases:
Our module passed all test cases.

Used machines:
We tested the module on Ubuntu 20.04 virtual machines, and on the Ubuntu VM provided by the course.

Notes:
Our code only supports 1 device, as the Assignment did not require more than 1 devices. So please do not change the parameter "SCULL_B_NR_DEVS".

